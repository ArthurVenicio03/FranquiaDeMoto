# projeto para uma diciplina da faculdade - Jonh Victor(Frontend e ux designer ) e Tainá Miranda(Backend e banco de dados)
 ## o sistema de franquia de motos visa permitir gerar infomações para auxliar na tomada de decisões estratégicas na empresa.

 ## php na versão 7.2 e seu framework na versão 5.8, wampp 2.3 e mysql 5.2 configurações necessárias para rodar o projeto no seu localhost
 ## páginas do sistema:s
 ### cadastro de fornecedores - [X]
 ### cadastro de produtos - [X]
 ### cadastro de lojas - [X]
 ### cadastro de vendas - [X]
 ### cadastro de clientes [X]
 
 ### gráficos de vendas por lojas [X]
 
 ## funcionalidade/metodos do sistema: 

 ### login 
 ### cadastro de fornecedores, produtos, lojas, vendas, clientes [X]s
  ### gráficos de vendas por lojas [X]

 ###  get/fornecedores [X]
  ###  post/fornecedores [X]

 ###  get/produtos [X]
  ###  post/produtos [X]

 ###  get/lojas [X]
  ###  post/lojas [X]

 ###  get/vendas [X]
  ###  post/vendas [X]

  ###  get/clientes [X]
 ###  post/clientes [X]
 
## atenção esse projeto encontra-se na fase de desenvolvimento e tem previsão de terminado até dia 30 de outubro.
 ### comando para rodar o projeto - php artisan serve
 ### comando para criar controller -  php artisan make:controller ClientesController
  ### comando para criar migrations - 

## Getting Started

First, install the package

```bash
composer install
```

configure o .env
```
php artisan key:generate
```
Second, run the development server:

```bash
php artisan serve
```

*Stacks:*
- PHP 7.1.3
- Laravel 5.8.
