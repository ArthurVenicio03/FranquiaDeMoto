<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FuncaoController extends Controller
{
    public function index(){
        $dados="oi";
        
        return $dados;
    }
    public function add(){
        
    }

    public function view(){
        
    }

    public function delete(){
        
    }
}
