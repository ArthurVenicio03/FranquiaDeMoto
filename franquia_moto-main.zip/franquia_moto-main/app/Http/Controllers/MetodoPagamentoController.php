<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MetodoPagamentoController extends Controller
{
    //
}
