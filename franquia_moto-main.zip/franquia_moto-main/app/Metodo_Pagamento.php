<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Metodo_Pagamento extends Model
{
    protected $table = 'metodo_pagamento';
}
